<?php
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="selecta.css">
</head>
<body>
    <div class="menu-bar">
        <img class="logo" src="logo.png" alt="" srcset="">
        <ul>
            <div class="name1"> Ashwin k</div>
            <div class="role1">(Inter)</div>
            <div class="tna">Home </div>
            <div class="lus">Profile</div>
            <div class="at">Documentation</div>

        </ul>
        
    
    <div class="container">
        <div class="split left">
            <h3 class="pro">Assign</h3>
            <div class="indent"><a href="profile.html">Dash board</a>>><a href=""">Assign</a> >></div>
                <div class="score ds">
                    <label class="ds1">20</label><br><label class="text1">Success</label>
                    

                </div>
                <div class="score as">
                    <label class="as1">20</label><br><label class="text2">Failure</label>
                    
                </div>
                <div class="sfm1">
                    <h3 class="sfm"> Success and Failure merits</h3>
                </div>
            </div>
        </div>
        <div class="split right">
            <div class="righ">
                <label class="r1">Assign the attack for analyst</label>
                <div class="button">
                    <button type="submit" class="attack1" onclick="window.location.href = 'beginning.php';">Beginner level</button>
                    <button type="submit" class="attack2" onclick="window.location.href = 'inter.php';">Intermediate level</button>
                    <button type="submit" class="attack3" onclick="window.location.href = 'expert.php';">Expert level</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
