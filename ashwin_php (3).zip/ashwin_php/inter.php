<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="inter.css">
</head>
<body>
    <div class="menu-bar">
        <img class="logo" src="logo.png" alt="" srcset="">
        <ul>
            <div class="name1"> Ashwin</div>
            <div class="role1"> (Intern)</div>
            <div class="tna">Home </div>
            <div class="lus">Profile</div>
            <div class="at">About Attack</div>

        </ul>
        
    
    <div class="container">
        <div class="split left">
            <h3 class="pro">Windows</h3>
            <div class="indent"><a href="profile.html">Dash board</a>>><a href="selecta.html">Assign</a> >> <a href="profile.html">Intermediate</a></div>
                <div class="score ds">
                    <label class="ds1">20</label><br><label class="text1">Success</label>
                    

                </div>
                <div class="score as">
                    <label class="as1">20</label><br><label class="text2">Failure</label>
                    
                </div>
                <div class="sfm1">
                    <h3 class="sfm"> Success and Failure merits</h3>
                </div>
            </div>
        </div>
        <div class="split right">
                <div><h3 class="pro1">Select the attack you want to assign for beginer</h3></div>
                <form>
                    <div class=" split1 ">
                        <div class="container">
                            <select name="" id="first">
                                <option value=""> Select the system </option>
                            </select>
                            <select name="" id="second">
                                <option value=""> Select the tatic </option>
                            </select>       
                            <select name="" id="third">
                                <option value=""> Selet the attack </option>
                            </select>
                            <select name="" id="third">
                                <option value=""> select the analyst </option>
                            </select>
                        </div>    
                    </div>
                    <button type="submit" class="button1" onclick="">Assign</button>
                </form>    
            </div>
        </div>  
    </div>
</div>
<script> var subjectObject = {
    "linux": {
      "Persistence": [" Modify Authentication Process: Pluggable Authentication Modules - T1556.003"],
      "Discovery": ["Permission Groups Discovery: Local Groups - T1069.001"],
      "Defense Evasion": ["Masquerading: Rename System Utilities - T1036.003"],
      "Impact": ['Resource Hijacking - T1496']

    },
    "windows": {
        "Defense Evasion": ["Masquerading: Rename System Utilities -T1036.003",'Hide Artifacts: Hidden Files and Directories - T1564.001','Hide Artifacts: Hidden Users - T1564.002','Hide Artifacts: Hidden Window - T1564.003'],
        "Discovery": ["Permission Groups Discovery: Local Groups - T1069.001"],
        "Execution": ['Command and Scripting Interpreter: Windows Command Shell - T1059.003'],
        "Impact": ["Inhibit System Recovery - T1490","Account Access Removal - T1531"],
        "Persistence": ['Office Application Startup: Office Test - T1137.002',
        'Office Application Startup: Add-ins - T1137.006',
        'BITS Jobs - T1197'],
    },
    "web application":{
      "Denial Of Service" : ['Documents'],
      "Web Defacement" : ['Create TABLE'],
    }
}



window.onload = function(){
    var first = document.getElementById('first')
    var second = document.getElementById('second')
    var third = document.getElementById('third')

    for(var x in subjectObject){
        // console.log(x);
        first.options[first.options.length] = new Option(x)
    }

    first.onchange = function(){
        second.length = 1
        third.length = 1

        second.style.display = 'block'
        third.style.display = 'none'

        for(var y in subjectObject[this.value]){
            // console.log(y);
            second.options[second.options.length] = new Option(y)
        }
    }


    second.onchange = function(){
        third.length = 1

        third.style.display = 'block'
        z = subjectObject[first.value][this.value]
        console.log(z);
        for(let i=0; i<z.length; i++){
            third.options[third.options.length] = new Option(z[i])
        }
    }
}</script>
</body>
</html>
