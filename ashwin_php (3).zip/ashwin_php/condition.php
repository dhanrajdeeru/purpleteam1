if($name == 'T1114.001')
{

}
else if($name == 'T1219')
{

}
else if($name == 'TOO3.001')
{

}
else if($name == 'TOO3.002')
{

}
else if($name == 'TOO3.003')
{

}
else if($name == 'T1552.001')
{

}
else if($name == 'T1552.002')
{

}
else if($name == 'T1552.006')
{

}
else if($name == 'T1555')
{

}
else if($name == 'T1555.003')
{

}
else if($name == 'T1036.003')
{

}
else if($name == 'T1564.001')
{

}
else if($name == 'T1564.002')
{

}
else if($name == 'T1564.003')
{

}
else if($name == 'T1007')
{

}
else if($name == 'T1012')
{

}
else if($name == 'T1049')
{

}
else if($name == 'T1069.001')
{

}
else if($name == 'T1087.001')
{

}
else if($name == 'T1047')
{

}
else if($name == 'T1053.005')
{

}
else if($name == 'T1059.003')
{

}
else if($name == 'T1106')
{

}
else if($name == 'T1569.002')
{

}
else if($name == 'T1489')
{

}
else if($name == 'T1490')
{

}
else if($name == 'T1531')
{

}
else if($name == 'T1078.001')
{

}
else if($name == 'T1133')
{

}
else if($name == 'T1566.001')
{

}
else if($name == 'T1137.002')
{

}
else if($name == 'T1137.006')
{

}
else if($name == 'T1197')
{

}
else if($name == 'T1055.001')
{

}
else if($name == 'T1134.002')
{

}
else if($name == 'T1134.004')
{

}

